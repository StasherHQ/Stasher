//
//  STCustomSwitchView.h
//  Stasher
//
//  Created by bhushan on 21/01/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STCustomSwitchView : UIView
{

}

@property (nonatomic, strong) IBOutlet UIButton *buttonFirst;
@property (nonatomic, strong) IBOutlet UIButton *buttonSecond;
@property (nonatomic, strong) IBOutlet UIImageView *imgViewGreen;

@end
