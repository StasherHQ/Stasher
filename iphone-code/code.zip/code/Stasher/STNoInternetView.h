//
//  STNoInternetView.h
//  Stasher
//
//  Created by Bhushan on 23/03/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STNoInternetView : UIView
{

}

- (id)initWithDefaultSizeandSuperView:(UIView*)thisSuperView;
@end
