//
//  BOABMutableURLRequest.m
//  BOABHTTPReq
//
//  Created by bhushan on 06/11/14.
//  Copyright (c) 2014 OAB. All rights reserved.
//

#import "BOABMutableURLRequest.h"

@implementation BOABMutableURLRequest
@synthesize userInfo;
@synthesize reqID;

@end
