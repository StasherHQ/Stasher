//
//  AvatarCollectionViewCell.h
//  Stasher
//
//  Created by Bhushan on 30/04/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AvatarCollectionViewCell : UICollectionViewCell
{


}

@property (nonatomic, strong)IBOutlet UIImageView *avatarImgView;
@end
