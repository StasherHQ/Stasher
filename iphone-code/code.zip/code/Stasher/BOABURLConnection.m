//
//  BOABURLConnection.m
//  BOABHTTPReq
//
//  Created by bhushan on 06/11/14.
//  Copyright (c) 2014 OAB. All rights reserved.
//

#import "BOABURLConnection.h"

@implementation BOABURLConnection
@synthesize userInfo;
@synthesize connID;
@end
