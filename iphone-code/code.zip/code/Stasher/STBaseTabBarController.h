//
//  STBaseTabBarController.h
//  Stasher
//
//  Created by bhushan on 13/11/14.
//  Copyright (c) 2014 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STBaseTabBarController : UITabBarController <UITabBarControllerDelegate, UITabBarDelegate, LogInManagerDelegate>
{

}


@end
