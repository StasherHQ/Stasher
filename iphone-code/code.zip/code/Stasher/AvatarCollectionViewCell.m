//
//  AvatarCollectionViewCell.m
//  Stasher
//
//  Created by Bhushan on 30/04/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import "AvatarCollectionViewCell.h"

@implementation AvatarCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
