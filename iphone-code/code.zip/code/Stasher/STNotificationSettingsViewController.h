//
//  STNotificationSettingsViewController.h
//  Stasher
//
//  Created by Bhushan on 30/04/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STNotificationSettingsViewController : UIViewController
{


}


@property (nonatomic, strong)IBOutlet UISwitch *notificationSwitch;
@property (nonatomic, strong)IBOutlet UILabel *labelSettingHeading;
@property (nonatomic, strong)IBOutlet UILabel *headerLabel;
@end
