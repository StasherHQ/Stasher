//
//  STActivityBGViewController.h
//  Stasher
//
//  Created by Bhushan on 03/06/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STActivityBGViewController : UIViewController

@end
