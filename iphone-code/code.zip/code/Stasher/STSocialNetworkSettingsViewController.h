//
//  STSocialNetworkSettingsViewController.h
//  Stasher
//
//  Created by Bhushan on 30/04/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STSocialNetworkSettingsViewController : UIViewController
{

}

@property (nonatomic, strong) IBOutlet UILabel *headerLabel;
@property (nonatomic, strong) IBOutlet UIButton *removeFbButton;
@end
