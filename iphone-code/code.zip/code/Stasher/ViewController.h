//
//  ViewController.h
//  Stasher
//
//  Created by bhushan on 10/11/14.
//  Copyright (c) 2014 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{

}


@property (nonatomic, strong) IBOutlet UIScrollView *tutorialsScrollview;
@property (nonatomic, strong) IBOutlet UIPageControl *pageControl;
@property (nonatomic, strong) IBOutlet UIButton *nextButton;
@end

