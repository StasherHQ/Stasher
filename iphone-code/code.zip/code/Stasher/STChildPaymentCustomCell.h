//
//  STChildPaymentCustomCell.h
//  Stasher
//
//  Created by bhushan on 05/01/15.
//  Copyright (c) 2015 OAB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STChildPaymentCustomCell : UITableViewCell
{

}

@property (nonatomic, strong) IBOutlet UIButton *parentNameButton;
@end
